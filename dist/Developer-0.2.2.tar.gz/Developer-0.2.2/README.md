This is a simple package for producing colored logs.

**Usage example:**

* from developer import developer*
* developer.log("Hello World!")*

## License

MIT License
