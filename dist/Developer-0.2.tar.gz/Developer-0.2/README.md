This is a simple package for outputting data to the terminal replacing the print function.

** Usage example: **
* import developer *
* developer.log("Hello World!") *

## License
MIT License
